package com.sai.passwordgui;

public class Main {
    public static void main(String[] args) {
        new PasswordGUI().setVisible(true);
    }
}
